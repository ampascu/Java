package eu.ase.poly;

//Create the Snake class which is inheriting Animal and it is adding the following private field:
//- length: float
//- Create default constructor and constructor with parameters - using super
//- create get/set methods with eventual throw Exception statement
//- overwrite display method from Animal class
public class Snake {
	
}
