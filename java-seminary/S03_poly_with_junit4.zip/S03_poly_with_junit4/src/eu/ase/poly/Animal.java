package eu.ase.poly;


// Create the Animal class which implements Action and Cloneable interface 
// and it has a private int non-static field weight with 
// default constructor and constructor with one parameter, 
// plus get and set methods
// implement public String display() method for returning a string which contain the Animal weight
public class Animal implements Action, Cloneable {

}
