package eu.ase.multi;

import java.util.concurrent.Callable;

/**
 * The Callable interface is similar to Runnable, in that both are designed for classes 
 * whose instances are potentially executed by another thread.
 *  
 * A Runnable, however, does not return a result and cannot throw a checked exception.
 * 
 * Runnable tasks can be run using the Thread class or ExecutorService 
 * whereas Callables can be run only using the ExecutorService.
 *
 */
public class MyCallableArray /* implements Callable<Long> */ {


}
