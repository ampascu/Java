package eu.ase.multi;

/**
 * We implement Runnable because we intend on running the inside processes
 * on a thread.
 *
 */
public class MyMultiThreadArray /* implements Runnable */ {

}
