package eu.ase.poly;

// create Action interface with eat() and sleep() methods which are returning void
public interface Action {
}
