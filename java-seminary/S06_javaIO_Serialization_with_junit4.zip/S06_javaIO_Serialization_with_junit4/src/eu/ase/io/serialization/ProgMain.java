package eu.ase.io.serialization;

/*
			URL url = new URL("https://www.google.ro/");
			Order order = new Order(url, "Gina", 124.3f);
			
			System.out.println("Before: " + order);
			
			order.saveOrder("myFile.txt");
			Order restoredOrder = order.restoreOrder("myFile.txt");
			
			System.out.println("After:  " + restoredOrder);
 */
public class ProgMain {

	public static void main(String[] args) {

	}
}
